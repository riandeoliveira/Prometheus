<div align="center">
  <h1>🚀 BinanceAPP 🚀</h1>
</div>

## 📚 Sobre

<!-- Uma breve descrição do seu projeto -->

## 🏗️ Desenvolvimento

<!-- Detalhes sobre o desenvolvimento -->

## 🕹️ Possui as seguintes funcionalidades:

- Funcionalidade 1
- Funcionalidade 2
- Funcionalidade 3

## 📝 Notas

<!-- Notas sobre o projeto -->

## 🔎 Demonstração

<div align="center">
  <img src=".github/demo.gif" alt="Application demo GIF">
</div>

## 💻 Como acessar

<!-- Onde a sua aplicação está hospedada? -->

## 🛠️ Tecnologias utilizadas

<br />

<div>
  <img src="https://skillicons.dev/icons?i=css" width="64" /> &nbsp;
  <img src="https://skillicons.dev/icons?i=firebase" width="64" /> &nbsp;
  <img src="https://skillicons.dev/icons?i=html" width="64" /> &nbsp;
  <img src="https://skillicons.dev/icons?i=js" width="64" /> &nbsp;
  <img src="https://skillicons.dev/icons?i=markdown" width="64" /> &nbsp;
  <img src="https://skillicons.dev/icons?i=next" width="64" /> &nbsp;
  <img src="https://skillicons.dev/icons?i=react" width="64" /> &nbsp;
  <img src="https://skillicons.dev/icons?i=ts" width="64" /> &nbsp;
</div>

<br />

<p align="center">✨ Made with 💙 by <a href="https://github.com/riandeoliveira"><strong>Rian Oliveira</strong></a> ✨</p>
